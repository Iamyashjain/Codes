import {
  createBrowserRouter,
  RouterProvider,
  Route,
  Outlet,
} from "react-router-dom";
import Navbar from "./layout/Navbar";
import Login from "./pages/user/Login";
import Stats from "./pages/admin/Stats";
import NotFoundPage from "./pages/user/NotFoundPage";
import InitiativeForm from "./pages/user/InitiativeForm";
import FeedbackForm from "./pages/user/FeedbackForm";
import AdvanceRegistration from "./pages/user/AdvanceRegistration";
import AdminPageLayout from "./layout/AdminPageLayout";
import MultiSelectBoxPage from "./pages/admin/MultiSelectBoxPage";

const Layout = () => {
  return (
    <div className="flex flex-col items-center ">
      <Navbar />
      <div>
        <div className="h-[93vh]">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      { path: "/", element: <Login /> },
      { path: "/Registration", element: <AdvanceRegistration /> },
      { path: "/Initiative", element: <InitiativeForm /> },
      {
        path: "/admin",
        element: <AdminPageLayout />,
        children: [
          { path: "Dashboard", element: <Stats /> },
          {
            path: "Table1",
            element: <MultiSelectBoxPage heading={"Table 1"} />,
          },
          {
            path: "Table2",
            element: <MultiSelectBoxPage heading={"Table 2"} />,
          },
          {
            path: "Table3",
            element: <MultiSelectBoxPage heading={"Table 3"} />,
          },
          {
            path: "Table4",
            element: <MultiSelectBoxPage heading={"Table 4"} />,
          },
        ],
      },
      { path: "/feedback", element: <FeedbackForm /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);

const App = () => {
  return <RouterProvider router={router} />;
};

export default App;
