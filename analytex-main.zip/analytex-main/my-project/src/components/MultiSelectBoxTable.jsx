import { useState } from "react";
import {
  Card,
  Table,
  TableRow,
  TableCell,
  TableHead,
  TableHeaderCell,
  TableBody,
  BadgeDelta,
  MultiSelect,
  MultiSelectItem,
} from "@tremor/react";

const salesPeople = [
  {
    name: "Peter Doe",
    leads: 45,
    sales: "1,000,000",
    quota: "1,200,000",
    variance: "low",
    region: "Region A",
    status: "overperforming",
    deltaType: "moderateIncrease",
  },
  {
    name: "Lena Whitehouse",
    leads: 35,
    sales: "900,000",
    quota: "1,000,000",
    variance: "low",
    region: "Region B",
    status: "average",
    deltaType: "unchanged",
  },
  {
    name: "Phil Less",
    leads: 52,
    sales: "930,000",
    quota: "1,000,000",
    variance: "medium",
    region: "Region C",
    status: "underperforming",
    deltaType: "moderateDecrease",
  },
  {
    name: "John Camper",
    leads: 22,
    sales: "390,000",
    quota: "250,000",
    variance: "low",
    region: "Region A",
    status: "overperforming",
    deltaType: "increase",
  },
  {
    name: "Max Balmoore",
    leads: 49,
    sales: "860,000",
    quota: "750,000",
    variance: "low",
    region: "Region B",
    status: "overperforming",
    deltaType: "increase",
  },
  {
    name: "Peter Moore",
    leads: 82,
    sales: "1,460,000",
    quota: "1,500,000",
    variance: "low",
    region: "Region A",
    status: "average",
    deltaType: "unchanged",
  },
  {
    name: "Joe Sachs",
    leads: 49,
    sales: "1,230,000",
    quota: "1,800,000",
    variance: "medium",
    region: "Region B",
    status: "underperforming",
    deltaType: "moderateDecrease",
  },
];

export default function MultiSelectBoxTable() {
  const [selectedNames, setSelectedNames] = useState([]);

  const isSalesPersonSelected = (salesPerson) =>
    selectedNames.includes(salesPerson.name) || selectedNames.length === 0;

  return (
    <Card className="w-[60vw] ">
      <MultiSelect
        onValueChange={setSelectedNames}
        placeholder="Select Salespeople..."
        className="max-w-xs"
      >
        {salesPeople.map((item) => (
          <MultiSelectItem key={item.name} value={item.name}>
            {item.name}
          </MultiSelectItem>
        ))}
      </MultiSelect>
      <Table className="mt-6">
        <TableHead className="">
          <TableRow>
            <TableHeaderCell className="text-left text-lg ">
              Name
            </TableHeaderCell>
            <TableHeaderCell className="text-right text-lg">
              Leads
            </TableHeaderCell>
            <TableHeaderCell className="text-right text-lg">
              Sales ($)
            </TableHeaderCell>
            <TableHeaderCell className="text-right text-lg">
              Quota ($)
            </TableHeaderCell>
            <TableHeaderCell className="text-right text-lg">
              Variance
            </TableHeaderCell>
            <TableHeaderCell className="text-right text-lg">
              Region
            </TableHeaderCell>
            <TableHeaderCell className="text-right text-lg">
              Status
            </TableHeaderCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {salesPeople
            .filter((item) => isSalesPersonSelected(item))
            .map((item) => (
              <TableRow key={item.name}>
                <TableCell className=" text-xl">{item.name}</TableCell>
                <TableCell className="text-right text-xl">
                  {item.leads}
                </TableCell>
                <TableCell className="text-right text-xl">
                  {item.sales}
                </TableCell>
                <TableCell className="text-right text-xl">
                  {item.quota}
                </TableCell>
                <TableCell className="text-right text-xl">
                  {item.variance}
                </TableCell>
                <TableCell className="text-right text-xl">
                  {item.region}
                </TableCell>
                <TableCell className="text-right text-xl">
                  <BadgeDelta deltaType={item.deltaType} size="xs">
                    {item.status}
                  </BadgeDelta>
                </TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    </Card>
  );
}
