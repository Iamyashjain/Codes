import React from "react";
import MultiSelectBoxTable from "../../components/MultiSelectBoxTable";

export default function MultiSelectBoxPage({ heading }) {
  return (
    <div>
      <h1 className="font-bold text-2xl ">{heading}</h1>
      <MultiSelectBoxTable />
    </div>
  );
}
