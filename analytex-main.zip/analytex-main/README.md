# analytex
One Stop solution for waste management

## tools used
React, Tremor.so, react-router 

## Learnings 
trying out state management with some UI libraries
